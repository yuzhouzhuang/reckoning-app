# The Reckoning App

Personal project for Imperial College

## Introduction

It is very time-consuming to calculate each share of bills and make the payment manually. This application will allow families or friends to work out joint payments and bills using a phone app.
The system creates a mobile tool app for users to split bills in an extremely convenient way.

## Product Perspective

The system is the replacement of the manual bill splitting process. The bill will be scanned and transformed digitally, and each participant will receive their bill automatically. The main goal of this project is to save time and improve efficiency.