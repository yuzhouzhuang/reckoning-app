import 'package:flutter/material.dart';

class MyColors {
  static const Color primaryColor = Color.fromRGBO(13, 132, 135, 1);
  static const Color primaryColorLight = Color.fromRGBO(68, 153, 171, 0.6);
}