import 'package:flutter/material.dart';

class SplashPage extends StatelessWidget {
  static const routeName = '/splashPage';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text('Splash Page'),
      ),
    );
  }
}
